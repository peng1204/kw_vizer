import os
import json
from difflib import SequenceMatcher
from typing import Optional

from langchain.prompts import PromptTemplate
from langchain_core.runnables import RunnableSequence
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_chroma import Chroma

from embedding2 import ko_embedding, client

# ✅ 벡터스토어 반환
def get_vectorstore(collection_name: str) -> Chroma:
    return Chroma(
        client=client,
        collection_name=collection_name,
        embedding_function=ko_embedding
    )

# ✅ Retriever 객체 생성
def get_retriever(collection_name: str):
    return get_vectorstore(collection_name).as_retriever(search_kwargs={"k": 20})

# ✅ Retrieval Chain 생성 (최신 방식)
def get_retrieval_qa(llm, prompt: PromptTemplate, collection_name: str):
    retriever = get_vectorstore(collection_name).as_retriever()

    # LLM 체인 구성: PromptTemplate → LLM 연결
    llm_chain = prompt | llm  # RunnableSequence
    stuff_chain = create_stuff_documents_chain(
        llm_chain_or_llm=llm_chain,  # ✅ 여기
        document_variable_name="context"
    )
    
    return RetrievalQA(
        retriever=retriever,
        combine_documents_chain=stuff_chain,
        input_key="question",
        output_key="result"
    )
    
    return retrieval_qa  # ✅ 필수 반환
    
# ✅ 시나리오 데이터 불러오기
SCENARIO_PATHS = [
    "/Users/hyunjin/Desktop/학습현황2.json",
    "/Users/hyunjin/Desktop/강의탐색3.json",
    "/Users/hyunjin/Desktop/진로상담.json"
]

def load_scenario_data() -> list[dict]:
    data = []
    for path in SCENARIO_PATHS:
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data.extend(json.load(f))
        else:
            print(f"⚠️ 시나리오 파일 없음: {path}")
    return data

SCENARIOS = load_scenario_data()

# ✅ 시나리오 기반 응답 (유사도 매칭)
def match_scenario_answer(user_input: str, threshold: float = 0.83) -> Optional[str]:
    norm_input = user_input.replace(" ", "").lower()
    best_score = 0
    best_answer = None

    for item in SCENARIOS:
        q = item.get("Text", "")
        a = item.get("Completion", "")
        q_norm = q.replace(" ", "").lower()
        score = SequenceMatcher(None, norm_input, q_norm).ratio()

        if score > best_score:
            best_score = score
            best_answer = a

    return best_answer if best_score >= threshold else None

# ✅ fallback: 세부전공 기반 유사도 답변
def find_best_matching_answer(user_input: str, user_id: str) -> str:
    major = "VT" if user_id == "kim" else "DS"
    major_data = [item for item in SCENARIOS if item.get("세부전공") == major]

    norm_input = user_input.replace(" ", "").lower()
    best_score = 0
    best_answer = None

    for item in major_data or SCENARIOS:
        q = item.get("Text", "")
        a = item.get("Completion", "")
        q_norm = q.replace(" ", "").lower()
        score = SequenceMatcher(None, norm_input, q_norm).ratio()
        if score > best_score:
            best_score = score
            best_answer = a

    return best_answer or "해당 질문에 대한 적절한 답변을 찾을 수 없습니다."

# ✅ 외부에 내보낼 함수들
__all__ = [
    "get_vectorstore",
    "get_retriever",
    "get_retrieval_qa",
    "match_scenario_answer",
    "find_best_matching_answer"
]