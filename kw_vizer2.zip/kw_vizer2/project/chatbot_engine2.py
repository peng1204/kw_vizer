# ✅ chatbot_engine2.py 수정안 (교수명 필터링 추가)

from retrieval2 import (
    get_retrieval_qa,
    get_vectorstore,
    match_scenario_answer,
    find_best_matching_answer
)
from embedding2 import ko_embedding
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from typing import Optional
import re

# ✅ 기능별 프롬프트
PROMPT_MAP = {
    "lecture": PromptTemplate(
        input_variables=["context", "question"],
        template="""
        교수님 이름은 정확하게 입력되었는지 확인하세요.
        반드시 \"수강신청 자료집.json\"과 \"수강신청_자료집_전체.pdf\"에서 lecture_professor 항목만 사용해 응답하세요.
        문서 외 정보 유추 금지. 예:
        \"조민수 교수님 강의 추천해줘\" → \"조민수 교수님의 강의 OOO 추천 드립니다.\"

        📄 문서: {context}
        💬 질문: {question}
        """
    ),
    "status": PromptTemplate(
        input_variables=["context", "question"],
        template="""
        성적 표현은 반드시 데이터에 있는 A+, A0, B+, B0 등으로만 응답하세요.
        졸업 요건은 2022학번 기준 133학점입니다.
        평균값 유추 금지.

        📄 문서: {context}
        💬 질문: {question}
        """
    ),
    "review": PromptTemplate(
        input_variables=["context", "question"],
        template="""
        조별과제 여부, 시험 난이도 관련 질문은 반드시 \"강의 평점.json\"만 사용해서 응답하세요.
        문서에 없는 내용은 \"정보가 제공되지 않았습니다\"라고 답변하세요.

        📄 문서: {context}
        💬 질문: {question}
        """
    ),
    "career": PromptTemplate(
        input_variables=["context", "question"],
        template="""
        진로 관련 답변은 반드시 수강 이력, 성적, 이수 과목 데이터를 기반으로만 응답하세요.
        일반화하거나 유추하지 마세요.

        📄 문서: {context}
        💬 질문: {question}
        """
    ),
    "general": PromptTemplate(
        input_variables=["context", "question"],
        template="""
        📄 문서: {context}
        💬 질문: {question}
        """
    )
}

# ✅ 교수명 추출
professor_list = ["이상민", "이수현", "최준호", "조민수", "박지현"]  # 예시

def extract_professor_name(text: str) -> Optional[str]:
    match = re.search(r"([가-힣]{2,4})\s*교수님", text)
    if match:
        return match.group(1)
    return None

# ✅ LLM 설정
llm = ChatOpenAI(temperature=0, model="gpt-4o")

# ✅ 질문 유형 감지
def detect_query_type(user_input: str) -> str:
    if "교수님" in user_input and "추천" in user_input:
        return "lecture"
    elif any(word in user_input for word in ["성적", "평균", "학점"]):
        return "status"
    elif any(word in user_input for word in ["조별과제", "시험", "팀플"]):
        return "review"
    elif any(word in user_input for word in ["진로", "취업", "직무"]):
        return "career"
    else:
        return "general"

# ✅ 핵심 응답 함수

def answer_query(user_id: str, user_input: str, collection_name: str) -> str:
    print(f"=== 🧠 answer_query 짱입 (user_id: {user_id}) ===")
    print(f"📦 선택된 컬러션 이름: {collection_name}")

    prof = extract_professor_name(user_input)
    if prof and prof not in professor_list:
        return f"{prof} 교수님의 수업 정보는 현재 제공되지 않았습니다."

    # 1. 시나리오 기반 매칭
    matched_answer = match_scenario_answer(user_input)
    if matched_answer:
        print("✅ 시나리오 매칭 성공")
        return matched_answer

    # 2. 프롬프트 기반 QA 시도
    try:
        query_type = detect_query_type(user_input)
        prompt = PROMPT_MAP[query_type]
        qa = get_retrieval_qa(llm, prompt, collection_name)
        result = qa.invoke({"question": user_input})
        print(f"🧠 생성형 응답 성공 ({query_type})")
        return result.get("result", "응답 생성 실패")
    except Exception as e:
        print(f"❌ 생성형 응답 실패: {e}")

    # 3. fallback
    fallback = find_best_matching_answer(user_input, user_id)
    print("🔁 fallback 응답 발환")
    return fallback

__all__ = ["answer_query"]
