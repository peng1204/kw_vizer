from langchain_chroma import Chroma
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from functools import lru_cache
from difflib import SequenceMatcher
from embedding import ko_embedding, embeddings_model, client, text_splitter

 #### 기능 구현 함수
import json
import re
import random
import itertools
from collections import defaultdict, Counter
        
import os
import json
from langchain_openai import OpenAIEmbeddings
from langchain_core.documents import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
import chromadb
from langchain.document_loaders import PyPDFLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
        
os.environ["OPENAI_API_KEY"] = "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"

embeddings_model = ko_embedding

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.3)

prompt = PromptTemplate(
            input_variables=["context", "question"],
            template=
                """❗ 반드시 아래 문서 내 정보만 사용해서 답변하세요.
                    ❌ 문서에 없는 정보는 생성하지 마세요.
                    ❌ 유추, 추론, 보완, 일반 상식 사용 금지.
                    
                        - 두 개 이상인 경우에는 **모두 나열**하세요.
                        - 조건에 맞는 강의가 없는 경우, "추천할 수 있는 과목이 없습니다."라고 하세요.
                        - "수강이력.json"에 있는 과목은 제외하고 추천하세요.
                        - 000교수님 강의 추천해줘 → 질문에는 "수강신청자료집.json"에서 lecture_professor항목에서 검색하여 대답하세요.
                        - 반드시 "수강신청 자료집.json"과 "수강신청_자료집_전체.pdf" 파일만 사용하세요.
                        - 교수님 이름을 헷갈리지 마고 정확히 적어주세요.
                        - 예: "OOO 교수님 강의 추천해줘" → "OOO 교수님의 강의 OOO 추천 드립니다."

                    ✅ **성적 응답**
                        - 성적 표현은 반드시 데이터에 있는 A+, A0, B+, B0, C+, C0, F 등등으로만 응답하세요.
                        - 예: "A+"를 물으면 A+만 보여주고, A0는 포함하지 마세요.
                        - 유사 성적 포함, 평균값 추론 등은 절대 하지 마세요.
                        - 졸업 학점 기준은 "2022학년도 입학자" 기준으로 133학점 입니다. 이에 맞춰서 졸업 가능 여부를 판단하세요.

                    ✅ **강의 평가 응답**
                        - 조별과제, 팀플 많음 여부, 시험 성적 너그러움 여부에 대한 질문은 **반드시 강의 평점.json 파일만 사용**해서 답하세요.

                    ✅ **답변 형식**
                        - 반드시 아래 말투와 형식을 따르세요:
                        - "자료구조 성적이 뭐야?" → "자료구조의 성적은 B+입니다."
                        - "내가 A+ 받은 과목 알려줘" → "OOO, OOO 과목에서 A+를 받으셨습니다."
                        - "객체지향프로그래밍이 전선이지?" → "네, 객체지향프로그래밍은 전필입니다."
                        - "전체 평균이 어떻게 돼?" → "전체 성적 평균은 3.58입니다."
                        - 답변 앞에 "답변:", "안녕하세요", "요약하자면" 등의 말은 **절대 붙이지 마세요.**
                        - 추가 질문 권유, 응원의 말은 절대 하지마세요.
                        
                        당신은 광운대학교 학사정보를 기반으로 한 진로상담 챗봇입니다. 다음 세 가지 기능을 수행합니다:

                            1. 강의탐색: 사용자에게 적절한 강의나 과목을 추천합니다.
                            2. 학습현황: 사용자의 성적 및 수강 과목 정보를 요약하거나 조회합니다.
                            3. 진로상담: 사용자 성적, 이수 과목 등을 바탕으로 진로 관련 질문에 응답합니다.

                            ❗ 반드시 아래 지침을 따르세요:

                            ✅ **데이터 제한**
                                - "강의탐색" 및 "학습현황" 기능은 반드시 제공된 pdf 및 json 내 데이터만을 사용하여 응답하세요.
                                - 데이터에 없는 정보는 절대 생성하거나 유추하지 마세요.
                                - 없으면 "해당 정보는 제공되지 않았습니다"라고 명확히 말하세요.

                            ✅ **강의 추천**
                                - 조건에 맞는 강의가 하나라면 **무 말, 불필요한 부연은 금지합니다.
                                - 광운대학교 외의 다른 학교에 대한 정보는 절대 제공하지 마세요.

                            📄 문서: {context}
                            💬 질문: {question}

                            지침을 반드시 지켜서 **자연스럽고 간결하게 말문을 여세요.**

                    문서 내용은 다음과 같은 형식을 따릅니다:
            
                        질문: ...
                        답변: ...
                        
                        사용자 질문과 가장 유사한 질문이 문서에 있을 경우,
                        해당 질문과 함께 적혀 있는 **답변만 그대로 출력**하세요.
                        
                        절대 새로운 문장을 생성하거나 다른 정보를 섞지 마세요.
                        
                ❗ 반드시 아래 문서 내 정보만 사용해서 답변하세요.
                    ❌ 문서에 없는 정보는 생성하지 마세요.
                    ❌ 유추, 추론, 보완, 일반 상식 사용 금지.
                    
                        - 두 개 이상인 경우에는 **모두 나열**하세요.
                        - 조건에 맞는 강의가 없는 경우, "추천할 수 있는 과목이 없습니다."라고 하세요.
                        - "수강이력.json"에 있는 과목은 제외하고 추천하세요.
                        - 000교수님 강의 추천해줘 → 질문에는 "수강신청자료집.json"에서 lecture_professor항목에서 검색하여 대답하세요.
                        - 반드시 "수강신청 자료집.json"과 "수강신청_자료집_전체.pdf" 파일만 사용하세요.
                        - 교수님 이름을 헷갈리지 마고 정확히 적어주세요.
                        - 예: "OOO 교수님 강의 추천해줘" → "OOO 교수님의 강의 OOO 추천 드립니다."

                    ✅ **성적 응답**
                        - 성적 표현은 반드시 데이터에 있는 A+, A0, B+, B0, C+, C0, F 등등으로만 응답하세요.
                        - 예: "A+"를 물으면 A+만 보여주고, A0는 포함하지 마세요.
                        - 유사 성적 포함, 평균값 추론 등은 절대 하지 마세요.
                        - 졸업 학점 기준은 "2022학년도 입학자" 기준으로 133학점 입니다. 이에 맞춰서 졸업 가능 여부를 판단하세요.

                    ✅ **강의 평가 응답**
                        - 조별과제, 팀플 많음 여부, 시험 성적 너그러움 여부에 대한 질문은 **반드시 강의 평점.json 파일만 사용**해서 답하세요.

                    ✅ **답변 형식**
                        - 반드시 아래 말투와 형식을 따르세요:
                        - "자료구조 성적이 뭐야?" → "자료구조의 성적은 B+입니다."
                        - "내가 A+ 받은 과목 알려줘" → "OOO, OOO 과목에서 A+를 받으셨습니다."
                        - "객체지향프로그래밍이 전선이지?" → "네, 객체지향프로그래밍은 전필입니다."
                        - "전체 평균이 어떻게 돼?" → "전체 성적 평균은 3.58입니다."
                        - 답변 앞에 "답변:", "안녕하세요", "요약하자면" 등의 말은 **절대 붙이지 마세요.**
                        - 추가 질문 권유, 응원의 말은 절대 하지마세요.
                        
                        당신은 광운대학교 학사정보를 기반으로 한 진로상담 챗봇입니다. 다음 세 가지 기능을 수행합니다:

                            1. 강의탐색: 사용자에게 적절한 강의나 과목을 추천합니다.
                            2. 학습현황: 사용자의 성적 및 수강 과목 정보를 요약하거나 조회합니다.
                            3. 진로상담: 사용자 성적, 이수 과목 등을 바탕으로 진로 관련 질문에 응답합니다.

                            ❗ 반드시 아래 지침을 따르세요:

                            ✅ **데이터 제한**
                                - "강의탐색" 및 "학습현황" 기능은 반드시 제공된 pdf 및 json 내 데이터만을 사용하여 응답하세요.
                                - 데이터에 없는 정보는 절대 생성하거나 유추하지 마세요.
                                - 없으면 "해당 정보는 제공되지 않았습니다"라고 명확히 말하세요.

                            ✅ **강의 추천**
                                - 조건에 맞는 강의가 하나라면 **무 말, 불필요한 부연은 금지합니다.
                                - 광운대학교 외의 다른 학교에 대한 정보는 절대 제공하지 마세요.

                            📄 문서: {context}
                            💬 질문: {question}

                            지침을 반드시 지켜서 **자연스럽고 간결하게 말문을 여세요."""
                        
                        

        )


def get_retriever(mode):
    persist_directory = f"./db/{mode}"
    embedding = HuggingFaceEmbeddings(model_name="jhgan/ko-sroberta-multitask")
    vectordb = Chroma(persist_directory=persist_directory, embedding_function=embedding)
    return vectordb.as_retriever()

vectorstore = Chroma(
            persist_directory="./chroma_db",
            collection_name="lecture_search",
            embedding_function=embeddings_model
        )
qa = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=vectorstore.as_retriever(search_kwargs={"k": 20}),
            chain_type="stuff",
            chain_type_kwargs={"prompt": prompt}
            
        )

# 자연어 질의 응답 처리 함수
def answer_query(user_input: str, user_id: str = "kim"):
            lowered = user_input.lower()
            normalized = lowered.replace(" ", "")

            collection_name = get_collection_name(user_input, user_id)
            
            # 졸업논문/프로젝트 관련 질의 선처리
            graduation_keywords = ["졸업논문", "졸업프로젝트", "졸프", "졸작", "졸업과제"]
            
            # 시기 관련 질의는 가장 먼저 처리
            if all(k in lowered for k in ["졸업", "논문", "프로젝트"]) and any(w in lowered for w in ["언제", "언제부터", "시기", "몇학년", "준비", "시작"]):
                return ("빠르면 3학년부터 준비하는 경우도 있지만, 대부분 3학년 2학기부터 팀을 구한 후 4학년 때 프로젝트를 진행합니다. 논문의 경우도 대부분 4학년 때 준비합니다.")
            
            # 필수 여부
            if all(k in lowered for k in ["졸업", "논문", "프로젝트"]) and any(w in lowered for w in ["필수", "의무", "꼭", "반드시", "필요", "해야", "해야해"]):
                return "졸업하기 위해서는 졸업 논문 혹은 졸업 프로젝트 둘 중 하나는 필수입니다."
            
            # 기타 졸프 관련 질의
            if any(k in lowered for k in graduation_keywords):
                return "졸업 논문이나 졸업 프로젝트와 관련된 사항은 전공 학과나 학교의 졸업 요건에 따라 다르며, 학과 사무실이나 지도 교수님을 통해 반드시 확인하셔야 합니다."

            # 특정 학점 + 과목 타입 필터
            if re.search(r'\d\s*학점', user_input):
                return get_lectures_by_credit_and_type(user_input)

            # 팀플 조건 분석 및 응답
            team_condition = normalize_team_condition(user_input)
            match = re.search(r'(\d+)\s*개', user_input)
            count = int(match.group(1)) if match else None

            if team_condition:
                BASE_PATH = "/Users/hyunjin/Desktop"

                filtered_lectures = filter_lectures_by_team(
            ["/Users/hyunjin/Desktop/kw_chatbot_data - 강의 평점.json"],
            team_condition
        )

                seen = set()
                unique_lectures = []
                for lec in filtered_lectures:
                    if lec["lecture_name"] not in seen:
                        seen.add(lec["lecture_name"])
                        unique_lectures.append(lec)
                if count:
                    unique_lectures = unique_lectures[:count]
                return format_team_project_response(team_condition, unique_lectures)

            # 성적 이하 필터
            if "이하" in normalized:
                for grade in GRADE_TO_POINT:
                    if grade.lower() in normalized:
                        threshold = GRADE_TO_POINT[grade]
                        target_grades = [g for g, p in GRADE_TO_POINT.items() if p <= threshold]
                        subjects = [r['lecture_name'] for r in load_student_data(user_id) if r['lecutre_grade'] in target_grades]
                        return f"{', '.join(subjects)} 과목이 {grade} 이하입니다." if subjects else f"{grade} 이하인 과목이 없습니다."

            # 전체 성적 평균 요청
            if any(k in normalized for k in ["전체성적평균", "전체학점평균"]):
                gpas = calculate_gpa_from_raw_split(user_id)
                if "전체" in gpas:
                    return f"{USER_NAME.get(user_id, user_id)}님의 전체 성적 평균은 {gpas['전체']}입니다."
                return "전체 성적 평균은 제공된 정보에 포함되어 있지 않습니다."

            # 전공 성적 평균 요청
            if "전공" in normalized and "평균" in normalized:
                gpas = calculate_gpa_from_raw_split(user_id)
                gpa = gpas.get("전공", None)
                name = USER_NAME.get(user_id, user_id)
                if gpa is not None:
                    return f"{name}님의 전공 성적 평균은 {gpa}입니다."
                return f"{name}님의 전공 성적 평균은 제공된 정보에 포함되어 있지 않습니다."

            # 재수강 횟수 조회
            if "재수강몇번했어" in normalized or "나몇번재수강했어" in normalized:
                retake_counts = count_retake_courses(user_id)
                if not retake_counts:
                    return "재수강한 과목이 없습니다."
                parts = [f"{name} 과목을 {count}번" for name, count in retake_counts.items()]
                return f"{', '.join(parts)} 재수강하셨습니다."

            # 단일 과목 성적 조회
            if "성적이어때" in normalized or "학점이어때" in normalized:
                course_name = user_input.split()[0].replace(" ", "")
                grade = get_course_grade(user_id, course_name)
                return f"{course_name}의 성적은 {grade}입니다." if grade else f"{course_name}에 대한 성적 정보를 찾을 수 없습니다."

            # 특정 성적 받은 과목 나열
            for grade in GRADE_TO_POINT:
                if grade.lower() in normalized and ("받은과목" in normalized or "받은수업" in normalized):
                    subjects = [r['lecture_name'] for r in load_student_data(user_id) if r['lecutre_grade'] == grade]
                    return f"{', '.join(subjects)} 과목에서 {grade}를 받으셨습니다." if subjects else f"{grade}를 받은 과목이 없습니다."

            # 재수강 목록 조회
            if "재수강한거뭐있어" in normalized or "재수강한과목" in normalized:
                data = load_student_data(user_id)
                names = [r['lecture_name'] for r in data if r.get('retake_status') == 'R']
                return ", ".join(f"{name}을 재수강했습니다." for name in names) if names else "재수강한 과목이 없습니다."

            # 재수강 반영한 평점 요청
            if any(k in normalized for k in ["재수강하고전체학점", "재수강반영된학점", "재수강적용학점", "재수강하고학점"]):
                return get_gpa_with_retake(user_id, exclude_pre_retake=True)

            # 재수강 가능한 전공 과목 요청
            if "재수강가능한전공과목" in normalized and any(k in normalized for k in ["뭐가있어", "뭐있어", "뭐야"]):
                filtered = get_filtered_retake_courses(user_id, focus="major")
                return f"지금 재수강 가능한 전공 과목은 {', '.join(filtered)}입니다." if filtered else "지금 재수강 가능한 전공 과목은 없습니다."

            # 전체 재수강 가능한 과목
            if "재수강가능한과목" in normalized and any(k in normalized for k in ["뭐가있어", "뭐있어", "뭐야"]):
                majors = get_filtered_retake_courses(user_id, focus="major")
                liberals = get_filtered_retake_courses(user_id, focus="liberal")
                total = majors + liberals
                return f"지금 재수강 가능한 과목은 {', '.join(total)}입니다." if total else "지금 재수강 가능한 과목은 없습니다."

            if "재수강가능한횟수" in normalized or ("재수강" in normalized and "횟수" in normalized):
                data = load_student_data(user_id)
                retake_count = sum(1 for r in data if r.get("retake_status") == "R" and r.get("lecutre_grade") != "F")
                remaining = 8 - retake_count
                name = USER_NAME.get(user_id, user_id)
                return f"{name}님은 총 8번까지 재수강이 가능하며, 현재까지 {retake_count}번 재수강하셨습니다. 따라서 {remaining}번 더 재수강할 수 있습니다."

            # 성적 향상 가정 시 GPA 시뮬레이션
            if ("재수강가능한과목" in normalized or "재수강가능한전공과목" in normalized) and "성적올리면" in normalized:
                focus = "major" if "전공" in normalized else "all"
                fixed_grade = None
                for grade in GRADE_TO_POINT:
                    if f"{grade.lower()}로" in normalized:
                        fixed_grade = grade
                        break
                return simulate_retake_gpa(user_id, fixed_grade=fixed_grade, focus=focus)

            if "조기졸업" in normalized and "가능" in normalized:
                data = load_student_data(user_id)
                credits = sum(r['lecture_credit'] for r in data if r.get('retake_or_delete_status') != "Y")
                grades = [GRADE_TO_POINT.get(r['lecutre_grade'], 0.0) for r in data if r.get('retake_or_delete_status') != "Y"]
                avg = round(sum(grades) / len(grades), 2) if grades else 0
            
                # C+ 이하 여부 체크
                bad_grades = {"C+", "C0", "F"}
                has_c_or_lower = any(
                    r.get('lecutre_grade') in bad_grades
                    for r in data if r.get('retake_or_delete_status') != "Y"
                )
            
                if credits >= 114 and avg >= 4.3 and not has_c_or_lower:
                    return "현재 조기 졸업 조건을 충족하셨습니다. 신청이 가능합니다."
                else:
                    message = (
                        "조기 졸업 가능 조건은 6학기 말까지 114학점 이상 취득(계절수업 제외), "
                        "7개 학기 이상 이수자로 학칙시행세칙 제16조 평점평균의 산출에 따른 총 평점평균이 4.3 이상인 자(학적부성적 기준), "
                        "조기졸업 신청 당해 학기까지 취득한 전과목 성적이 B0 이상인 자(학적부성적 기준)입니다."
                    )
                    if has_c_or_lower:
                        message += " 현재 C+ 이하의 성적이 존재하므로 재수강을 통해 성적을 개선하고 평점 평균을 4.3 이상으로 만든다면 조기 졸업이 가능합니다."
                    return message

            if "장학금" in normalized:
                if any(k in normalized for k in ["화도", "동해"]) and "최소" in normalized and "학점" in normalized:
                    return "화도·동해 장학금은 직전 학기 12학점 이상, 평점 2.0 이상이어야 신청 가능합니다."
                if "성적" in normalized:
                    return "성적 장학금은 평량평균이 3.0 이상이며, 17학점 이상 취득(4학년은 12학점), 그 중 60% 이상이 전공 학점일 경우 자동 신청됩니다."

            if "졸업필수과목" in normalized:
                return check_graduation_required_courses(user_id, "/Users/hyunjin/Desktop/kw_chatbot_data - 수강신청자료집.json")

            if "졸업하려면몇학점남았어" in normalized:
                return get_remaining_credits(user_id)
                
            ####################
            # 단순 고정 응답 처리
            
            if "졸업유예" in normalized:
                return "아니요. 우리 학교에서는 졸업 유예 신청이 불가능합니다."

            if "재수강" in normalized and "표시" in normalized:
                return "재수강한 과목은 성적표에 ‘R’(Retake)로 표기되며, 재수강한 과목의 성적만 성적 및 학점에 반영됩니다."

            if "f받고재수강" in normalized or ("f" in normalized and "재수강" in normalized):
                return "F 받은 과목은 재수강 시 '재수강' 표시가 뜨지 않지만, 재수강 이력은 남고 성적표에는 'R'로 표기됩니다."

            if "동일과목" in normalized and "몇번" in normalized:
                return "C+ 이하인 동일과목은 최대 2회까지 재수강 가능하며, 전체 재학 중 재수강 가능한 교과목 수는 최대 8과목입니다. F 학점은 제외됩니다."
                
            if "휴학" in normalized and "몇번" in normalized:
                return "일반휴학을 최대 6학기(3년) 할 수 있으며, 한 번 신청 시 최대 2학기 가능합니다. 군휴학 및 창업휴학은 일반휴학 기간에 포함되지 않습니다. 특별한 사유가 있을 경우 추가 휴학이 가능할 수도 있습니다. (단, 일반휴학기간은 한 번에 두 학기를 초과하지 못하며, 통산 3년(6학기)(연속해서는 2년)을 초과하지 못합니다.)"

            if "같은과목" in normalized and "재수강" in normalized and ("교수" in normalized or "사라지" in normalized or "폐지" in normalized):
                return "학정번호 기준으로 동일한 학정번호가 있는 강의를 수강하시면 됩니다. 다만, 동일한 학정번호의 강의가 3년 이상 미개설 할 경우, C이하의 과목은 학점삭제 가능합니다. 자세한 내용은 학사에 문의하세요."
            ####################    
            
            #재수강 vs 새로운 전공과목 선택 질문
            if any(x in normalized for x in ["재수강", "다시듣는", "다시 들어야", "낮은성적"]) and any(y in normalized for y in ["전공", "필수", "과목", "수업"]):
                data = load_student_data(user_id)
                low_grade_threshold = 2.5
                low_major_required = []

                for record in data:
                    grade_str = record.get("lecutre_grade")
                    grade = GRADE_TO_POINT.get(grade_str, 5)
                    ctype = record["lecture_course_type"]
                    name = record["lecture_name"]

                    if not ctype.startswith("전"):
                        continue
                    if grade > low_grade_threshold:
                        continue
                    if record.get("retake_or_delete_status") == "Y":
                        continue

                    low_major_required.append((grade_str, name))

                name = USER_NAME.get(user_id, user_id)
                response = f"재수강 여부는 개인의 학업 목표와 상황에 따라 다르지만, 성적이 낮은 전공 과목을 재수강하는 것은 전공에 대한 이해도를 높이고 평점 평균을 개선하는 데 도움이 될 수 있습니다. 반면, 다른 전공 과목을 듣는다면 다양한 지식을 쌓을 수 있는 기회가 될 수 있습니다."

                if not low_major_required:
                    response += f" 현재 성적을 고려할 때, 성적이 낮은 전공 과목은 확인되지 않았습니다."
                else:
                    parts = [f"{grade}를 받은 {name} 과목" for grade, name in low_major_required]
                    response += " 현재 성적을 고려할 때, 재수강이 가능한 전공 과목으로는 " + " / ".join(parts) + "이 있습니다."

                return response
        
            if "이수한과목" in normalized or "이수한수업" in normalized or "과목리스트" in normalized or "수업리스트" in normalized or "들은과목" in normalized or "지금까지이수한" in normalized:
                data = load_student_data(user_id)
                name = USER_NAME.get(user_id, user_id)
                grouped = defaultdict(list)
            
                for r in data:
                    if r.get("retake_or_delete_status") == "Y":
                        continue
                    ctype = r["lecture_course_type"]
                    grade = r["lecutre_grade"]
                    lecture = r["lecture_name"]
                    retake_mark = ", R" if r.get("retake_status") == "R" else ""
                    grouped[ctype].append(f"{lecture}({grade}{retake_mark})")
            
                order = ["전필", "전선", "교필", "교선"]
                lines = [f"{ctype}: {' / '.join(grouped[ctype])}" for ctype in order if ctype in grouped]
            
                if not lines:
                    return f"{name}님께서 이수하신 과목이 확인되지 않았습니다."
                return f"{name}님께서 현재까지 이수하신 과목 목록:\n" + "\n".join(lines)

            # 2. 시나리오 매칭
            scenario_ans = match_scenario_answer(user_input)
            if scenario_ans:
                return scenario_ans

            # 3. 벡터 검색 결과에서 응답 찾기
            similar_docs = vectorstore.similarity_search_with_score(user_input, k=3)
            for doc, score in similar_docs:
                if "질문:" in doc.page_content and "답변:" in doc.page_content:
                    try:
                        return doc.page_content.split("답변:")[1].strip()
                    except:
                        continue

            # 4. LLM 기반 QA 시도
            try:
                result = qa.invoke({"query": user_input})["result"].strip()
                if result and "찾을 수 없습니다" not in result:
                    return result
            except Exception:
                pass

            # 🔧 5. 최후 fallback - 세부전공 기반 시나리오 중 가장 유사한 항목
            return find_best_matching_answer(user_input, user_id)

def find_best_matching_answer(user_input, user_id):
            major = "VT" if user_id == "kim" else "DS"
            major_data = [item for item in SCENARIOS if item.get("세부전공") == major]
            if not major_data:
                major_data = SCENARIOS  # fallback to all if major tag missing

            norm_input = user_input.replace(" ", "").lower()
            best_score = 0
            best_answer = None

            for item in major_data:
                q = item.get("Text", "")
                a = item.get("Completion", "")
                q_norm = q.replace(" ", "").lower()
                score = SequenceMatcher(None, norm_input, q_norm).ratio()
                if score > best_score:
                    best_score = score
                    best_answer = a

            return best_answer if best_answer else "해당 질문에 대한 적절한 답변을 찾을 수 없습니다."
        
 # LangChain 컬렉션 이름 결정 함수
def get_collection_name(user_input: str, user_id: str) -> str:
            q = user_input.lower()
            if "진로" in q or "상담" in q:
                return "career_counsel"
            elif "이수" in q or "학점" in q or "현황" in q or "평균" in q:
                return "academic_status"
            return f"lecture_search_{user_id}"

        # 입력 분류 함수
def classify_function(user_input: str) -> str:
            if "강의" in user_input or "탐색" in user_input:
                return "lecture_search"
            elif "진로" in user_input or "상담" in user_input:
                return "career_counsel"
            elif "학업" in user_input or "현황" in user_input:
                return "academic_status"
            else:
                return "lecture_search"

        # 캐시: 팀플 조건에 따라 결과 재사용
TEAM_CACHE = {}

        # JSON 파일에서 팀플 조건과 일치하는 강의 필터링
def filter_lectures_by_team(json_files, team_condition):
            if team_condition in TEAM_CACHE:
                return TEAM_CACHE[team_condition]

            result = []
            for file in json_files:
                with open(file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for item in data:
                    team_value = item.get("lecture_team", "").strip()
                    lecture_id = item.get("lecture_id")
                    lecture_name = item.get("lecture_name")

                    if not lecture_id or not lecture_name:
                        continue

                    if team_condition == "없음" and team_value in ["없음", "0"]:
                        result.append({"lecture_id": lecture_id, "lecture_name": lecture_name})
                    elif team_condition == "보통" and team_value in ["보통", "적은"]:
                        result.append({"lecture_id": lecture_id, "lecture_name": lecture_name})
                    elif team_condition == "많은" and team_value in ["많은", "많음"]:
                        result.append({"lecture_id": lecture_id, "lecture_name": lecture_name})

            TEAM_CACHE[team_condition] = result
            return result

        # 팀플 응답 메시지 포맷
def format_team_project_response(team_condition: str, lectures: list):
            if not lectures:
                return f"팀플이 {team_condition} 강의를 찾을 수 없습니다."

            condition_map = {
                "없음": "없는",
                "보통": "적은",
                "많은": "많은"
            }
            label = condition_map.get(team_condition, team_condition)
            header = f"팀플이 {label} 강의는 다음과 같습니다:"
            body = "\n".join(
                f"{i+1}. {lec['lecture_name']} (학정번호: {lec['lecture_id']})"
                for i, lec in enumerate(lectures)
            )
            return f"{header}\n{body}"

        # JSON 내 팀플 조건 처리 핸들러
def handle_team_project_query(user_input, json_path):
            condition = normalize_team_condition(user_input)
            if not condition:
                return None

            filtered_lectures = filter_lectures_by_team([json_path], condition)
            seen = set()
            unique_lectures = []
            for lec in filtered_lectures:
                if lec["lecture_name"] not in seen:
                    seen.add(lec["lecture_name"])
                    unique_lectures.append(lec)

            return format_team_project_response(condition, unique_lectures)

        # 학점 및 교과구분에 따른 강의 필터링
def get_lectures_by_credit_and_type(user_input: str):
            credit_match = re.search(r'(\d)\s*학점', user_input)
            if not credit_match:
                return "몇 학점짜리 수업을 원하시는지 알려주세요. 예: '2학점 교양 수업 알려줘'"
            credit = int(credit_match.group(1))

            # 수업 유형 필터링
            course_types = []
            if "전필" in user_input:
                course_types = ["전필"]
            elif "전선" in user_input:
                course_types = ["전선"]
            elif "교필" in user_input:
                course_types = ["교필"]
            elif "교선" in user_input:
                course_types = ["교선"]
            elif "전공" in user_input:
                course_types = ["전필", "전선"]
            elif "교양" in user_input:
                course_types = ["교필", "교선"]
            else:
                course_types = ["전필", "전선", "교필", "교선"]

            count_match = re.search(r'(\d+)\s*개', user_input)
            limit = int(count_match.group(1)) if count_match else None

            with open("/Users/hyunjin/Desktop/kw_chatbot_data - 수강신청자료집.json", "r", encoding="utf-8") as f:
                course_data = json.load(f)

            results = []
            seen = set()
            for item in course_data:
                course_type = item.get("lecture_course_type", "").strip()
                credit_val = item.get("lecture_hours") or item.get("lecture_credit")
                if not credit_val:
                    continue
                try:
                    credit_val = int(str(credit_val).strip())
                except:
                    continue

                professor = item.get("lecture_professor", "").strip()
                lecture_name = item.get("lecture_name", "").strip()
                key = (lecture_name, professor)

                if course_type in course_types and credit_val == credit and key not in seen:
                    seen.add(key)
                    results.append(f"{lecture_name} (학정번호: {item['lecture_id']}) - {professor or '교수명 없음'}")

            if not results:
                return f"{credit}학점짜리 {', '.join(course_types)} 과목을 찾을 수 없습니다."

            if limit:
                random.shuffle(results)
                results = results[:limit]

            header = f"{credit}학점짜리 {', '.join(course_types)} 과목 목록입니다:"
            lines = [f"{i+1}. {lec}" for i, lec in enumerate(results)]
            return header + "\n" + "\n".join(lines)

        # 성적 → 평점 매핑
GRADE_TO_POINT = {
            "A+": 4.5, "A0": 4.0, "B+": 3.5, "B0": 3.0,
            "C+": 2.5, "C0": 2.0, "F": 0.0
        }

        # 수강이력 불러오기 (ID → 파일명 매핑)
BASE_PATH = "/Users/hyunjin/Desktop"

def load_student_data(user_id: str):
            name = "김브티" if user_id == "kim" else "홍데사"
            filename = os.path.join(BASE_PATH, f"kw_chatbot_data - {name}_수강이력.json")
            with open(filename, encoding="utf-8") as f:
                return json.load(f)
            

        # 재수강 횟수 계산
def count_retake_courses(user_id: str):
            data = load_student_data(user_id)
            course_count = defaultdict(int)
            for record in data:
                if record.get("retake_status") == "R":
                    course_count[record["lecture_name"]] += 1
            return course_count

        # 특정 과목의 성적 조회
def get_course_grade(user_id: str, course_name: str):
            data = load_student_data(user_id)
            for record in data:
                if record["lecture_name"].replace(" ", "") == course_name.replace(" ", ""):
                    return record["lecutre_grade"]
            return None

        # 사용자 이름 매핑
USER_NAME = {
            "kim": "김브티",
            "hong": "홍데사"
        }

        # 평균 평점 계산 함수
        # GPA 계산 함수 (재수강 반영 여부 및 전공 필터 포함)
def get_gpa_with_retake(user_id: str, exclude_pre_retake: bool = False, course_type: str = None):
            data = load_student_data(user_id)
            seen = {}
            credits, total = 0, 0
            for record in data:
                key = record['lecture_id']
                grade = record['lecutre_grade']
                credit = record['lecture_credit']
                ctype = record['lecture_course_type']

                if course_type:
                    if course_type == "전공" and not ctype.startswith(("전필", "전선")):
                        continue
                    elif course_type != "전공" and not ctype.startswith(course_type):
                        continue

                if exclude_pre_retake and record.get('retake_or_delete_status') == 'Y':
                    continue

                if record.get('retake_status') == 'R':
                    seen[key] = (GRADE_TO_POINT[grade], credit)
                elif key not in seen:
                    seen[key] = (GRADE_TO_POINT[grade], credit)

            for point, credit in seen.values():
                credits += credit
                total += point * credit

            if credits == 0:
                return "계산할 수 있는 학점이 없습니다."
            name = USER_NAME.get(user_id, user_id)
            return f"{name}님의 평균 평점은 {round(total / credits, 2)}입니다."

        # 재수강한 과목 리스트 반환
def get_retake_course_names(user_id: str):
            data = load_student_data(user_id)
            names = [r['lecture_name'] for r in data if r.get('retake_or_delete_status') == 'Y']
            return names

        # 재수강한 과목 개수 반환
def get_retake_course_count(user_id: str):
            return len(get_retake_course_names(user_id))

        # 특정 성적을 받은 과목 조회 함수
def get_subjects_by_grade(user_id: str, target_grade: str):
            data = load_student_data(user_id)
            return [r['lecture_name'] for r in data if r['lecutre_grade'] == target_grade]

        # 특정 과목의 최종 성적 반환 함수
def get_final_grade_for_subject(user_id: str, subject_name: str):
            data = load_student_data(user_id)
            matches = [r for r in data if r['lecture_name'] == subject_name]
            if not matches:
                return None
            return matches[-1]['lecutre_grade']

        # 재수강 횟수 과목별로 반환
def get_retake_course_counts(user_id: str):
            data = load_student_data(user_id)
            names = [r['lecture_name'] for r in data if r.get('retake_status') == 'R']
            return Counter(names)

        # 재수강 가능 과목 조회 함수 (정확하게 재수강 제외 기준 반영)
def get_possible_retake_gpa(user_id: str, focus: str = "all", list_only: bool = False, fixed_grade: str = None):
            data = load_student_data(user_id)
            seen = {}
            excluded = {}

            # 재수강 후 B0 이상 받은 과목 제외
            for record in data:
                key = record['lecture_id']
                grade = record['lecutre_grade']
                if record.get('retake_status') == 'R' and GRADE_TO_POINT.get(grade, 0) >= 3.0:
                    excluded[key] = True

            for record in data:
                key = record['lecture_id']
                grade = record['lecutre_grade']
                ctype = record['lecture_course_type']

                if record.get('retake_or_delete_status') == 'Y': continue
                if key in excluded: continue
                if focus == "major" and not ctype.startswith("전공"): continue
                if GRADE_TO_POINT.get(grade, 5) > 2.5: continue
                if key not in seen:
                    seen[key] = (GRADE_TO_POINT[grade], record['lecture_credit'], record['lecture_name'])

            if list_only:
                if not seen:
                    return f"지금 재수강 가능한 {'전공 ' if focus == 'major' else ''}과목은 없습니다."
                return f"재수강 가능한 {'전공 ' if focus == 'major' else ''}과목: " + ", ".join([v[2] for v in seen.values()])

def check_graduation_required_courses(user_id: str, required_json_path: str):
            # 필수 과목 목록 추출
            with open(required_json_path, encoding='utf-8') as f:
                all_courses = json.load(f)

            required = {
                (item['lecture_name'], item['lecture_course_type'])
                for item in all_courses
                if item.get('lecture_course_type') in ["교필", "전필"]
            }

            # 사용자가 이수한 과목 목록
            data = load_student_data(user_id)
            taken = {
                (record['lecture_name'], record['lecture_course_type'])
                for record in data
                if record.get("retake_or_delete_status") != "Y"
            }

            taken_required = sorted(required & taken, key=lambda x: x[1])  # 이수한 필수
            missed_required = sorted(required - taken, key=lambda x: x[1])  # 미이수 필수

            def format_list(items):
                result = defaultdict(list)
                for name, typ in items:
                    result[typ].append(name)
                return result

            taken_fmt = format_list(taken_required)
            missed_fmt = format_list(missed_required)

            response_parts = []
            if taken_fmt:
                parts = [f"{typ} 과목인 {', '.join(names)}" for typ, names in taken_fmt.items()]
                response_parts.append("졸업 필수 과목 중에서 " + "과 " .join(parts) + "를 이수하셨고")
            if missed_fmt:
                parts = [f"{typ} 과목인 {', '.join(names)}" for typ, names in missed_fmt.items()]
                response_parts.append(" ".join(parts) + "를 이수하지 않았습니다.")
            if not missed_required:
                response_parts = ["졸업 필수 과목을 모두 이수하셨습니다."]
            return " ".join(response_parts)

def get_remaining_credits(user_id: str, graduation_total: int = 133):
            data = load_student_data(user_id)
            total_credits = sum(
                record['lecture_credit']
                for record in data
                if record.get('retake_or_delete_status') != "Y"
            )
            remaining = graduation_total - total_credits
            name = USER_NAME.get(user_id, user_id)
            return f"{name}님의 현재까지 이수한 학점은 {total_credits}학점이며, 졸업을 위해 {remaining}학점이 더 필요합니다."

def calculate_gpa_from_raw_split(user_id: str) -> dict:
            data = load_student_data(user_id)
            name = USER_NAME.get(user_id, user_id)

            total_points, total_credits = 0, 0
            major_points, major_credits = 0, 0

            for record in data:
                if record.get('retake_or_delete_status') == 'Y':
                    continue

                grade = record.get('lecutre_grade')
                point = GRADE_TO_POINT.get(grade, None)
                credit = record.get('lecture_credit', 0)
                ctype = record.get('lecture_course_type', '')

                if point is None or not isinstance(credit, (int, float)):
                    continue

                # 전체 평점 누적
                total_points += point * credit
                total_credits += credit

                # 전공 평점 누적 (전필 또는 전선만)
                if ctype.startswith("전필") or ctype.startswith("전선"):
                    major_points += point * credit
                    major_credits += credit

            result = {}
            if total_credits > 0:
                result["전체"] = round(total_points / total_credits, 2)
            if major_credits > 0:
                result["전공"] = round(major_points / major_credits, 2)
            else:
                result["전공"] = None  # 또는 "전공 과목 없음"

            return result

        # 성적 향상 가정 시 GPA 시뮬레이션 함수 개선
def simulate_retake_gpa(user_id: str, fixed_grade: str = None, focus: str = "all"):
            if fixed_grade == "A+":
                return "재수강 시 받을 수 있는 최고학점은 A0입니다."

            data = load_student_data(user_id)
            seen = {}
            excluded = set()

            for record in data:
                key = record['lecture_id']
                grade = record['lecutre_grade']
                if record.get('retake_status') == 'R' and GRADE_TO_POINT.get(grade, 0) >= 3.0:
                    excluded.add(key)
                if record.get('retake_or_delete_status') == 'Y':
                    excluded.add(key)

            replace_targets = {}
            base = {}
            for record in data:
                key = record['lecture_id']
                grade = record['lecutre_grade']
                credit = record['lecture_credit']
                ctype = record['lecture_course_type']
                name = record['lecture_name']

                if key in excluded:
                    continue
                if GRADE_TO_POINT.get(grade, 5) > 2.5:
                    continue
                if focus == 'major' and not ctype.startswith("전공"):
                    continue
                if focus == 'liberal' and ctype.startswith("전공"):
                    continue

                if key not in replace_targets:
                    replace_targets[key] = (GRADE_TO_POINT[grade], credit, name)

            for record in data:
                key = record['lecture_id']
                if record.get('retake_or_delete_status') == 'Y':
                    continue
                base[key] = (GRADE_TO_POINT.get(record['lecutre_grade'], 0.0), record['lecture_credit'])

            grade_options = [fixed_grade] if fixed_grade else ["A0", "B+", "B0", "C+", "C0"]
            result_lines = []

            for g in grade_options:
                modified = base.copy()
                label = []
                for key, (_, credit, name) in replace_targets.items():
                    modified[key] = (GRADE_TO_POINT[g], credit)
                    label.append(f"{name}: {g}")
                total_credits = sum(c for _, c in modified.values())
                total_points = sum(p * c for p, c in modified.values())
                avg = round(total_points / total_credits, 2)
                result_lines.append(f"{' / '.join(label)} → 예상 평점: {avg}")

            return "\n".join(result_lines)

def get_retake_reason_summary(user_id: str) -> str:
            data = load_student_data(user_id)
            results = []

            for record in data:
                name = record.get('lecture_name')
                grade = record.get('lecutre_grade')
                course_type = record.get('lecture_course_type', '')
                is_retake = record.get('retake_status') == 'R'
                is_dropped = record.get('retake_or_delete_status') == 'Y'

                if is_dropped:
                    continue
                if not course_type.startswith("전필"):
                    continue
                if grade not in ["C+", "C0", "F"]:
                    continue

                msg = f"{name}에서 {grade}를 받으셨습니다"
                if is_retake:
                    msg += ", 재수강하셨습니다"
                results.append(msg)

            if not results:
                return "성적이 낮은 전공 필수 과목은 없습니다."

            return "전공 필수 과목 중 성적이 낮은 과목은 " + " / ".join(results) + "."

            # GPA simulation part
            original_data = load_student_data(user_id)
            base = {}
            for r in original_data:
                key = r['lecture_id']
                if r.get('retake_or_delete_status') == 'Y': continue
                base[key] = (GRADE_TO_POINT.get(r['lecutre_grade'], 0.0), r['lecture_credit'])

            replace_targets = list(seen.items())
            grade_options = [fixed_grade] if fixed_grade else list(GRADE_TO_POINT.keys())
            responses = []

            for combo in itertools.product(grade_options, repeat=len(replace_targets)):
                modified = base.copy()
                label = []
                for (key, (_, credit, name)), g in zip(replace_targets, combo):
                    modified[key] = (GRADE_TO_POINT[g], credit)
                    label.append(f"{name}: {g}")
                total_credits = sum(c for _, c in modified.values())
                total_points = sum(p * c for p, c in modified.values())
                avg = round(total_points / total_credits, 2)
                responses.append(f"{' / '.join(label)} → 예상 평점: {avg}")

            return "\n".join(responses)
# 재수강 가능 과목 필터링 함수 (전공/교양 구분 포함)
def get_filtered_retake_courses(user_id: str, focus: str = "all") -> list:
            data = load_student_data(user_id)
            seen = {}
            excluded = set()

            # 재수강했고 성적이 B0 이상이면 제외
            for record in data:
                key = record['lecture_id']
                grade = record['lecutre_grade']
                if record.get('retake_status') == 'R' and GRADE_TO_POINT.get(grade, 0) >= 3.0:
                    excluded.add(key)
                if record.get('retake_or_delete_status') == 'Y':
                    excluded.add(key)

            # 재수강 조건에 부합하는 과목 수집
            for record in data:
                key = record['lecture_id']
                grade = record['lecutre_grade']
                ctype = record['lecture_course_type']
                name = record['lecture_name']

                if key in excluded:
                    continue
                if GRADE_TO_POINT.get(grade, 5) > 2.5:
                    continue
                if focus == 'major' and not ctype.startswith("전공"):
                    continue
                if focus == 'liberal' and ctype.startswith("전공"):
                    continue
                if key not in seen:
                    seen[key] = name

            return list(seen.values())

        # 팀플 조건별 응답 포맷 구성
def format_team_project_response(team_condition: str, lectures: list):
            if not lectures:
                return f"팀플이 {team_condition} 강의를 찾을 수 없습니다."

            condition_map = {
            "없음": "없는",
            "보통": "적은",
            "많은": "많은"
            }
            label = condition_map.get(team_condition, team_condition)
            header = f"팀플이 {label} 강의는 다음과 같습니다:"
            body = "\n".join(
                f"{i+1}. {lec['lecture_name']} (학정번호: {lec['lecture_id']})"
                for i, lec in enumerate(lectures)
            )
            return f"{header}\n{body}"

        # 조별과제/팀플 조건 파싱 및 정규화
def normalize_team_condition(user_input: str) -> str | None:
            condition_map = {
                "없음": ["팀플 없는", "팀플이 없는", "조별과제 없는", "조별과제가 없는"],
                "보통": ["팀플 보통", "팀플이 보통", "조별과제 보통", "조별과제가 보통", "팀플 적은", "팀플이 적은", "조별과제 적은", "조별과제가 적은"],
                "많은": ["팀플 많은", "팀플이 많은", "조별과제 많은", "조별과제가 많은", "팀플 많음", "조별과제 많음"]
            }
            for condition, variants in condition_map.items():
                if any(v in user_input for v in variants):
                    return condition
            return None

        # Load scenario data
SCENARIO_FILES = [os.path.join(BASE_PATH, fname) for fname in ["학습현황2.json","강의탐색2.json","진로상담.json"]]

def load_scenario_data():
            data = []
            for path in SCENARIO_FILES:
                try:
                    with open(path, encoding="utf-8") as f:
                        data.extend(json.load(f))
                except FileNotFoundError:
                    print(f"⚠️ 파일 누락: {path}")
            return data

SCENARIOS = load_scenario_data()

def match_scenario_answer(user_input: str, threshold: float = 0.83) -> str | None:
            norm_input = user_input.replace(" ", "").lower()
            best_score = 0
            best_answer = None

            for item in SCENARIOS:
                q = item.get("Text", "")
                a = item.get("Completion", "")
                q_norm = q.replace(" ", "").lower()
                score = SequenceMatcher(None, norm_input, q_norm).ratio()
                if score > best_score:
                    best_score = score
                    best_answer = a

            return best_answer if best_score >= threshold else None

        
def run_chatbot(user_input: str, user_id: str = "kim") -> str:
    return answer_query(user_input, user_id)
        

       
            
        
# Remove or comment out this function, as 'qa' is not defined in this scope.
# If you need to expose answer_query, use the one defined inside run_chatbot or refactor accordingly.
# def answer_query(query, mode):
#     # If you want to use the RetrievalQA chain defined above, use 'qa' instead of 'rag_chain'
#     # If you have a different chain, make sure to define or import it before use
#     # Example using 'qa' (already defined above):
#     result = qa.invoke({"query": query})["result"]
#     return result