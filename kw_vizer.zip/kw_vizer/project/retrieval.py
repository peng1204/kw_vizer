# retrieval.py
from langchain.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

embedding = HuggingFaceEmbeddings(model_name="jhgan/ko-sroberta-multitask")

# 이미 저장된 DB 경로에서 불러오기
db = Chroma(persist_directory="./chroma_store/", embedding_function=embedding)

retriever = db.as_retriever()
